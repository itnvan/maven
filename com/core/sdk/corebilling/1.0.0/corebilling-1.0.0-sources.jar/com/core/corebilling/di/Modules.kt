package com.core.corebilling.di

import com.core.corebilling.BillingConfig
import com.core.corebilling.BillingManager
import org.koin.android.ext.koin.androidApplication
import org.koin.core.module.Module
import org.koin.dsl.module

fun billingModule(config: BillingConfig): Module =
    module {
        single { BillingManager(androidApplication(), config) }
    }
