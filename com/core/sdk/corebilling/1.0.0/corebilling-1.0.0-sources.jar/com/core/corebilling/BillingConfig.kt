package com.core.corebilling

import com.android.billingclient.api.Purchase

data class BillingProduct(
    val id: String,
    val type: ProductType = ProductType.SUBS,
    val consumable: Boolean = false,
)

data class BillingConfig(
    val products: List<BillingProduct>,
    val connectTimeoutMs: Long = 10_000L,
    val fetchTimeoutMs: Long = 20_000L,
    val queryTimeoutMs: Long = 10_000L,
    val onInitDone: ((startTime: Long, success: Boolean) -> Unit)? = null,
    val onConsume: ((purchase: Purchase) -> Unit)? = null,
    /**
     * Called on the main thread for every purchased non-consumable (subscription or one-time product) each time the purchases are
     * read, after it is acknowledged. The same purchase comes again on every refresh: grant once per `purchaseToken`.
     */
    val onEntitlement: ((purchase: Purchase) -> Unit)? = null,
    /**
     * true = every start (and every return to the foreground) reads the purchases and the products again, ignoring the cached
     * expiration, and the products are fetched even when something is owned. For apps that sell several products.
     */
    val alwaysSync: Boolean = false,
) {
    /** Consumables must be read on every start (a pack bought elsewhere or left unconsumed), so they turn [alwaysSync] on. */
    internal val syncOnStart: Boolean
        get() = alwaysSync || products.any { it.consumable }
}
