package com.core.corecore.remoteconfig

import com.core.corecore.preference.CoreSharedPref
import com.core.corecore.tracking.SdkInitReporter
import com.google.firebase.Firebase
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.remoteConfig
import com.google.firebase.remoteconfig.remoteConfigSettings
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import timber.log.Timber

class RemoteConfigManager(
    private var pref: CoreSharedPref,
    private val options: RemoteConfigOptions,
) {

    private val TAG: String
        get() = this::class.java.simpleName

    private val _fetchedFlow = MutableStateFlow(false)
    val fetchedStateFlow = _fetchedFlow.asStateFlow()

    init {
        fetchRemoteConfig()
    }

    fun fetchRemoteConfig() {
        Timber.tag(TAG).d("fetchRemoteConfig: start fetching")
        val start = System.currentTimeMillis()

        if (pref.fetchedRemoteConfig) {
            Timber.tag(TAG).d("fetchRemoteConfig: cache-first, unblock splash immediately")
            _fetchedFlow.value = true
        }

        val errorHandler = CoroutineExceptionHandler { _, throwable ->
            Timber.tag(TAG).e("fetchRemoteConfig: error ${throwable.message}")
            SdkInitReporter.onDone?.invoke(SDK_KEY, start, false)
            _fetchedFlow.value = true
        }
        CoroutineScope(Dispatchers.IO + errorHandler).launch {
            val remoteConfig = Firebase.remoteConfig
            val configSettings = remoteConfigSettings {
                this.setFetchTimeoutInSeconds(options.timeoutSeconds)
                this.minimumFetchIntervalInSeconds = options.minimumFetchIntervalSeconds
            }
            remoteConfig.setConfigSettingsAsync(configSettings)

            attemptFetch(remoteConfig, start, errorHandler, attempt = 1)
        }
    }

    // attempt tinh tu 1; maxRetryRc = tong so lan fetch toi da (1 = khong retry).
    private fun attemptFetch(
        remoteConfig: FirebaseRemoteConfig,
        start: Long,
        errorHandler: CoroutineExceptionHandler,
        attempt: Int,
    ) {
        remoteConfig.fetchAndActivate().addOnCompleteListener { task ->
            CoroutineScope(Dispatchers.IO + errorHandler).launch {
                if (task.isSuccessful) {
                    // Moi key remote deu ghi thang vao prefs. SDK con tu khai property tren
                    // CoreSharedPref de doc lai (vd adsConfigJson) - core khong biet key cua ai.
                    for (key in remoteConfig.getKeysByPrefix("")) {
                        val rawValue = remoteConfig.getValue(key)
                        if (rawValue.source != FirebaseRemoteConfig.VALUE_SOURCE_REMOTE) continue
                        when {
                            rawValue.isLong() -> {
                                pref.put(key, rawValue.asLong())
                                Timber.tag(TAG).d("fetchRemoteConfig long: $key: ${rawValue.asLong()}")
                            }

                            rawValue.isDouble() -> {
                                pref.put(key, rawValue.asDouble().toFloat())
                                Timber.tag(TAG).d("fetchRemoteConfig double: $key: ${rawValue.asDouble()}")
                            }

                            rawValue.isBoolean() -> {
                                pref.put(key, rawValue.asBoolean())
                                Timber.tag(TAG).d("fetchRemoteConfig boolean: $key: ${rawValue.asBoolean()}")
                            }

                            rawValue.isString() -> {
                                val value = rawValue.asString()
                                pref.put(key, value)
                                Timber.tag(TAG).d(
                                    if (value.length > MAX_LOG_LENGTH) {
                                        "fetchRemoteConfig string: $key: len=${value.length}"
                                    } else {
                                        "fetchRemoteConfig string: $key: $value"
                                    },
                                )
                            }
                        }
                    }
                    pref.fetchedRemoteConfig = true
                    Timber.tag(TAG).d("fetchRemoteConfig: success (attempt $attempt)")
                    SdkInitReporter.onDone?.invoke(SDK_KEY, start, true)
                    _fetchedFlow.value = true
                } else {
                    if (attempt < options.maxRetry) {
                        Timber.tag(TAG).e(
                            "fetchRemoteConfig: fail attempt $attempt/${options.maxRetry}, retry sau ${options.retryDelayMs}ms",
                        )
                        delay(options.retryDelayMs)
                        attemptFetch(remoteConfig, start, errorHandler, attempt + 1)
                    } else {
                        Timber.tag(TAG).e("fetchRemoteConfig: fail sau $attempt lan")
                        SdkInitReporter.onDone?.invoke(SDK_KEY, start, false)
                        _fetchedFlow.value = true
                    }
                }
            }
        }
    }

    private companion object {
        const val MAX_LOG_LENGTH = 200
        const val SDK_KEY = "remote_config"
    }
}
