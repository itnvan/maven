package com.core.corecore

import android.app.Application
import android.content.Context
import com.core.corecore.preference.CoreSharedPref
import com.core.corecore.remoteconfig.RemoteConfigManager
import com.core.corecore.remoteconfig.RemoteConfigOptions

// Diem lay prefs/RemoteConfig dung chung cho moi SDK embed core: khong can Koin, khong can app truyen vao.
// RC BAT BUOC 1 instance: moi instance tu fetch trong init{} nen 2 instance = 2 lan fetch.
object CoreCore {

    @Volatile
    private var options = RemoteConfigOptions()

    @Volatile
    private var prefsInstance: CoreSharedPref? = null

    @Volatile
    private var rcInstance: RemoteConfigManager? = null

    // Chi an TRUOC lan remoteConfig() dau tien (coreads goi trong BaseAds.init - createdAtStart).
    fun configure(options: RemoteConfigOptions) {
        this.options = options
    }

    // Moi instance deu mo cung file getSharedPreferences(packageName) nen du app/SDK khac tu tao
    // subclass rieng, du lieu van la mot.
    fun prefs(context: Context): CoreSharedPref =
        prefsInstance ?: synchronized(this) {
            prefsInstance ?: CoreSharedPref(context.app()).also { prefsInstance = it }
        }

    fun remoteConfig(context: Context): RemoteConfigManager =
        rcInstance ?: synchronized(this) {
            rcInstance ?: RemoteConfigManager(prefs(context), options).also { rcInstance = it }
        }

    private fun Context.app(): Application = applicationContext as Application
}
