package com.core.corecore.remoteconfig

// Tham so fetch cua RC. Tach rieng de core khong phai biet AppConfig (co field rieng cua ads).
data class RemoteConfigOptions(
    val timeoutSeconds: Long = 5,
    val minimumFetchIntervalSeconds: Long = 3600,
    val maxRetry: Int = 5,
    val retryDelayMs: Long = 100,
)
